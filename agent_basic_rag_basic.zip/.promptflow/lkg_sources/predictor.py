import pandas as pd
from promptflow import tool
from sklearn.linear_model import LinearRegression

url = "https://stdvillacres446355269001.blob.core.windows.net/d28648db-7469-4bd3-a45f-130512d482c6-azureml-blobstore/UI/2025-04-20_092854_UTC/historic_data.csv"
# Read CSV directly
df_net_balance = pd.read_csv(url)


# The inputs section will change based on the arguments of the tool function, after you save the code
# Adding type to arguments and return value will help the system show the types properly
# Please update the function name/signature per need
@tool
def my_python_tool(client_id: str) -> str:
    # Filtrar datos del cliente
    df_client = df_net_balance[df_net_balance['ClientID'] == client_id].copy()
    if df_client.shape[0]==0:
        return 'Cliente no encontrado'
    # Convertir fecha a número ordinal (requerido por la regresión)
    df_client['DateOrdinal'] = pd.to_datetime(df_client['Date']).map(pd.Timestamp.toordinal)

    # Variables de entrada (X) y salida (y)
    X = df_client[['DateOrdinal']]
    y = df_client['NetBalance']

    # Entrenar regresión lineal
    model = LinearRegression()
    model.fit(X, y)

    # Predecir el siguiente día
    next_day = df_client['DateOrdinal'].max() + 1
    predicted_balance = model.predict([[next_day]])[0]

    return f"Fecha de predicción: {pd.Timestamp.fromordinal(next_day).date()}. Balance neto predicho {round(predicted_balance, 2)}"